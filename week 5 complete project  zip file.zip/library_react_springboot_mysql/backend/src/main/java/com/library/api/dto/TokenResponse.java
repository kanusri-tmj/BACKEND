package com.library.api.dto;

public record TokenResponse(String accessToken, String tokenType) {}
